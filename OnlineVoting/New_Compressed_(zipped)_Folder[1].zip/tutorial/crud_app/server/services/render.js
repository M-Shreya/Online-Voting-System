const axios = require('axios');

exports.homeRoutes = (req, res) => {
    // Make a get request to /api/users
    axios.get("http://localhost:3000/api/users")
    .then(function(response){
        res.render('index', {users: response.data});
        console.log("All User data fetched sucessfully !!");
    })
    .catch(err =>{
        res.send(err);
    })
}

exports.userRoutes = (req, res) => {
    // Render add_user.pug
    res.render('add_user');
}

exports.updateUserRoutes = (req, res) => {
    axios.get("http://localhost:3000/api/users", {params: {id:req.query.id}})
    .then(function(userdata){
        res.render("update_user", {user: userdata.data});
    }).catch(err =>{
        res.send(err);
    })
}